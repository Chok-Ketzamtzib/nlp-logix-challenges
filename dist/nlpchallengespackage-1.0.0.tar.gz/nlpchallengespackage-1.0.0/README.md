# nlp-logix-challenges
The following are the dependencies used for these challenges:
`sklearn`
`pandas`
The Anaconda package includes the above dependencies. The installation instructions are on the [Anaconda Documentation](https://docs.anaconda.com/anaconda/install/index.html)
